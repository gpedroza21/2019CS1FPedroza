$(".bigThing").click(
    function(){
        var color = $(this).css("background-color");
        $().css();
        $().text();
    }
);